</script>
<script defer src="js/jquery.flexslider.js"></script>
<script type="text/javascript">
    $(function() {
        //SyntaxHighlighter.all();
    });
    $(window).load(function() {
        $('.flexslider').flexslider({
            animation: "slide",
            start: function(slider) {
                $('body').removeClass('loading');
            }
        });
    });
</script>
